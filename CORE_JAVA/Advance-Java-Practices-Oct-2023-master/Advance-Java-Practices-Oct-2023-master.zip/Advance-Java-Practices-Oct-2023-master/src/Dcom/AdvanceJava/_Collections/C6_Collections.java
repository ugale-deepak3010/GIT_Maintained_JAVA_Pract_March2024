package Dcom.AdvanceJava._Collections;

/*
Ordering
Duplicates
Speed
Memory

1.	All types of collections are implements Iterable methods! 
				it have foreach method.
2.	Collection interface which extends Iterable.
 		add, remove, isEmpty, toArray..
3. There is no classes directly. There is another layer of iterfaces.
		Set: Do not allow duplicate. unordered
		List: Allow duplicate. Ordered.
		Queue: FIFO
		Map:  Key:Value pair. unordered. No duplicate. Does not extends Collection Interface but Still Collection..

 */
public class C6_Collections{

	public static void main(String[] args) {
		

	}

}
