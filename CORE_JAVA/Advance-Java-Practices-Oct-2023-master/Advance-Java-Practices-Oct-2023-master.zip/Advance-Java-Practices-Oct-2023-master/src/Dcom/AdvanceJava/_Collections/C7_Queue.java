package Dcom.AdvanceJava._Collections;

/*

Linked list using implement the Queue.
 

 */

public class C7_Queue {

	public static void main(String[] args) {
		
	}

}
