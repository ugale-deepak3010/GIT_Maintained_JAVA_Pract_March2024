package Ecom.AdvanceJava._Programming;

/*

Parallel Stream is use on huge data.
it allow to run parallel on multi core processor.
for less data use normal Stream.

it's used for performance improvement.

 */
public class D5_ParallelStream {

	public static void main(String[] args) {
		// Refer Stream examples.

	}

}
