package Ecom.AdvanceJava._Programming;

@FunctionalInterface
public interface GreetingMessage {
	public abstract void greet(String name);

}
