package Ecom.AdvanceJava._Programming;

@FunctionalInterface
public interface Shapes {
	public abstract int getArea(Square person);
}

//Square used for Method References.