package Fcom.AdvanceJava._Modular.Exporting;

import java.awt.image.BufferedImage;

public class F1_Module {

	public static void main(String[] args) {

		BufferedImage bufferedImage = new BufferedImage(1, 1, 1);
		System.out.println("Hello "+ bufferedImage.toString());

	}

}
