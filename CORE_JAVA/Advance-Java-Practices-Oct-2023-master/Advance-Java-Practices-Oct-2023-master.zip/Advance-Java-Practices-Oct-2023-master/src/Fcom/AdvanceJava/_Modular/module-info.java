
module MyModule {
	requires java.desktop;
	
	//exports Ecom.AdvanceJava._Programming;
}