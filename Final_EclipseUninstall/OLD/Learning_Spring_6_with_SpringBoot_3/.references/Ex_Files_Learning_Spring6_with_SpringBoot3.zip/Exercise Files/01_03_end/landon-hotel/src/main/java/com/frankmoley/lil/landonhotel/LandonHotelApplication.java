package com.frankmoley.lil.landonhotel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LandonHotelApplication {

  public static void main(String[] args) {
    SpringApplication.run(LandonHotelApplication.class, args);
  }

}
