package com.DataRESTDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataRestDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataRestDemoApplication.class, args);
	}

}
