package com.SpringSecurityApp;

import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;

public class MvcConfigurer extends WebSecurityConfiguration {

}
