package com.SpringSecurityApp;

public class MyController {

}
