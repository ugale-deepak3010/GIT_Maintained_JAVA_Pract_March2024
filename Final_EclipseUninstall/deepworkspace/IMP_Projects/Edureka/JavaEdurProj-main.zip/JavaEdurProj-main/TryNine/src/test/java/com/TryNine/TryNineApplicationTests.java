package com.TryNine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TryNineApplicationTests {

	@Test
	void contextLoads() {
	}

}
